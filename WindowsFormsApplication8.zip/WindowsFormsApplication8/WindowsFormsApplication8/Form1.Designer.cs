﻿namespace WindowsFormsApplication8
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.FrenchLanguageRadioButton = new System.Windows.Forms.RadioButton();
            this.EnglishLanguageRadioButton = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.EmployeeNametextBox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.CalculateBMIButton = new System.Windows.Forms.Button();
            this.PrintMessageButton = new System.Windows.Forms.Button();
            this.ClearFormButton = new System.Windows.Forms.Button();
            this.LogopictureBox = new System.Windows.Forms.PictureBox();
            this.groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogopictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.FrenchLanguageRadioButton);
            this.groupBox.Controls.Add(this.EnglishLanguageRadioButton);
            this.groupBox.Location = new System.Drawing.Point(250, 23);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(212, 115);
            this.groupBox.TabIndex = 2;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "Languages";
            // 
            // FrenchLanguageRadioButton
            // 
            this.FrenchLanguageRadioButton.AutoSize = true;
            this.FrenchLanguageRadioButton.Location = new System.Drawing.Point(72, 63);
            this.FrenchLanguageRadioButton.Name = "FrenchLanguageRadioButton";
            this.FrenchLanguageRadioButton.Size = new System.Drawing.Size(65, 17);
            this.FrenchLanguageRadioButton.TabIndex = 0;
            this.FrenchLanguageRadioButton.Text = "Français";
            this.FrenchLanguageRadioButton.UseVisualStyleBackColor = true;
            this.FrenchLanguageRadioButton.CheckedChanged += new System.EventHandler(this.FrenchLanguageRadioButton_CheckedChanged);
            // 
            // EnglishLanguageRadioButton
            // 
            this.EnglishLanguageRadioButton.AutoSize = true;
            this.EnglishLanguageRadioButton.Checked = true;
            this.EnglishLanguageRadioButton.Location = new System.Drawing.Point(72, 40);
            this.EnglishLanguageRadioButton.Name = "EnglishLanguageRadioButton";
            this.EnglishLanguageRadioButton.Size = new System.Drawing.Size(59, 17);
            this.EnglishLanguageRadioButton.TabIndex = 0;
            this.EnglishLanguageRadioButton.TabStop = true;
            this.EnglishLanguageRadioButton.Text = "English";
            this.EnglishLanguageRadioButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 156);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Employee\'s Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Employee ID:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Hours Worked:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(76, 283);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Total Sales:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(76, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Sales Bonus:";
            // 
            // EmployeeNametextBox
            // 
            this.EmployeeNametextBox.Location = new System.Drawing.Point(250, 156);
            this.EmployeeNametextBox.Name = "EmployeeNametextBox";
            this.EmployeeNametextBox.Size = new System.Drawing.Size(212, 20);
            this.EmployeeNametextBox.TabIndex = 13;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(250, 201);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 14;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(250, 241);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 15;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(250, 283);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 16;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(250, 318);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 17;
            // 
            // CalculateBMIButton
            // 
            this.CalculateBMIButton.Location = new System.Drawing.Point(47, 398);
            this.CalculateBMIButton.Name = "CalculateBMIButton";
            this.CalculateBMIButton.Size = new System.Drawing.Size(92, 32);
            this.CalculateBMIButton.TabIndex = 18;
            this.CalculateBMIButton.Text = "Calculate";
            this.CalculateBMIButton.UseVisualStyleBackColor = true;
            // 
            // PrintMessageButton
            // 
            this.PrintMessageButton.Location = new System.Drawing.Point(187, 398);
            this.PrintMessageButton.Name = "PrintMessageButton";
            this.PrintMessageButton.Size = new System.Drawing.Size(87, 32);
            this.PrintMessageButton.TabIndex = 19;
            this.PrintMessageButton.Text = "Print";
            this.PrintMessageButton.UseVisualStyleBackColor = true;
            // 
            // ClearFormButton
            // 
            this.ClearFormButton.Location = new System.Drawing.Point(322, 398);
            this.ClearFormButton.Name = "ClearFormButton";
            this.ClearFormButton.Size = new System.Drawing.Size(88, 32);
            this.ClearFormButton.TabIndex = 20;
            this.ClearFormButton.Text = "Clear";
            this.ClearFormButton.UseVisualStyleBackColor = true;
            // 
            // LogopictureBox
            // 
            this.LogopictureBox.Image = ((System.Drawing.Image)(resources.GetObject("LogopictureBox.Image")));
            this.LogopictureBox.Location = new System.Drawing.Point(21, 23);
            this.LogopictureBox.Name = "LogopictureBox";
            this.LogopictureBox.Size = new System.Drawing.Size(194, 115);
            this.LogopictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogopictureBox.TabIndex = 21;
            this.LogopictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 464);
            this.Controls.Add(this.LogopictureBox);
            this.Controls.Add(this.ClearFormButton);
            this.Controls.Add(this.PrintMessageButton);
            this.Controls.Add(this.CalculateBMIButton);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.EmployeeNametextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox);
            this.Name = "Form1";
            this.Text = "Sales Bonus";
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogopictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.RadioButton FrenchLanguageRadioButton;
        private System.Windows.Forms.RadioButton EnglishLanguageRadioButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EmployeeNametextBox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button CalculateBMIButton;
        private System.Windows.Forms.Button PrintMessageButton;
        private System.Windows.Forms.Button ClearFormButton;
        private System.Windows.Forms.PictureBox LogopictureBox;
    }
}

