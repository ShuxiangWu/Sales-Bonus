<!DOCTYPE html>
<html lang="zh">
<head>   
    <link rel="stylesheet" href="styles.css">
    <meta charset="utf-8">
</head>
<body>
         <li><a class="active" href="index.php" title="Home">Home</a></li>
         <li><a class="active" href="login.php" title="Logout">Login</a></li>
        <h1 class="header">TO DO LIST!</h1>
        <ul class="items">
    
                <li>This is assignment 1, todo list.</li>
                <li>This is Shuxiang WU 200279010. </li>
            </ul>

        <?php
            if (isset($errorMessage)) {
                echo $errorMessage;
                unset($errorMessage);
            }
        ?>
</body>
</html>
