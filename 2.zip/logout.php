<?php
/*when succussful, whatt will happen*/
    session_start();
    session_destroy();
    header('Location: index.php');
