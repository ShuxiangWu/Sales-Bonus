<?php
/*design login information*/
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = empty($_POST['username']) ? '' : $_POST['username'];
        $password = empty($_POST['password']) ? '' : $_POST['password'];
        if ($username == 'shuxiangwu' && $password == '123456') {
            session_start();
            $_SESSION['username'] = $username;
            header('Location: todo.php');
        } else {
            $errorMessage = "something wrong！";
            header('Location: index.php');
        }
    }
?>
<!DOCTYPE html>
<html lang="zh">
<head>   
    <link rel="stylesheet" href="styles.css">
    <meta charset="utf-8">
    <title>Login</title>
</head>
<body>
    <li><a class="active" href="index.php" title="Home">Home</a></li>
    <li><a class="active" href="login.php" title="Login">Login</a></li>
    <h1 class="header">Login</h1>

    <form name="login" method="post" action="login.php">
        <p>
            <label>name：</label>
            <div class="col-10">
            <input name="username" type="text" placeholder="User Name">
        </p>
        <p>
            <label>password：</label>
            <div class="col-10">
            <input name="password" type="password">
        </p>
        <button>login</button>
    </form>
    <p style="color:grey">* name is shuxiangwu and password is 123456.</p>
</body>
</html>