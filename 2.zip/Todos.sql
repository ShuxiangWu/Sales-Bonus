USE Todos;
SHOW TABLES;
DROP TABLE IF EXISTS todos ;
DROP TABLE IF EXISTS todoList;

CREATE TABLE logins 
(
	name VARCHAR(80) PRIMARY KEY,
    password VARCHAR(80) NOT NULL
);
INSERT INTO logins VALUES 	('shuxiangwu','123456');


CREATE TABLE todoList (
    ID VARCHAR(60) NOT NULL,
    name VARCHAR(30) NOT NULL,
    completed TINYINT(20),
    notes VARCHAR(800),
    FOREIGN KEY (userid)
	REFERENCES logins (username)
);
INSERT INTO todoList VALUES 	('1','shuxiangwu',1,'a student');
INSERT INTO todoList VALUES 	('2','Ton',0,'a student');
DESC todoList;
SELECT*FROM todoList;
DESC logins;
SELECT*FROM logins;
SELECT * FROM todoList WHERE ID = 'shuxiangwu';