<?php
 class TodoList
    {
        public function addItem($item)
        {
            $_SESSION['TodoList'][] = $item;
        }

        public function editItem($position, $item)
        {
            $_SESSION['TodoList'][$position - 1] = $item;
        }

        public function removeItem($position)
        {
            unset($_SESSION['TodoList'][$position - 1]);
        }
    }
    $list = new TodoList();
    session_start();
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (!empty($_POST['addItem'])) {
            $list->addItem($_POST['addItem']);
        }
        if (!empty($_POST['editPosition'])) {
            $list->editItem($_POST['editPosition'], $_POST["editItem{$_POST['editPosition']}"]);
        }
        if (!empty($_POST['removePosition'])) {
            $list->removeItem($_POST['removePosition']);
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="utf-8">
    
</head>
<body>
         <li><a class="active" href="index.php" title="Home">Home</a></li>
         <li><a class="active" href="logout.php" title="Logout">Logout</a></li>
        <h1 class="header">Todo List</h1>
    <p>
        <form method="post" action="todo.php">
            <input name="addItem" type="text" placeholder="Id/name/compeleted/notes">
            <button>add</button>
        </form>
    </p>
   
    <form method="post" action="todo.php">
        <?php foreach ((array)$_SESSION['TodoList'] as $key => $item): ?>
            <input type="checkbox">
            <input name="editItem<?= $key + 1?>" type="text" value="<?= $item ?>">
            <button name="editPosition" value="<?= $key + 1 ?>">save</button>
            <button name="removePosition" value="<?= $key + 1 ?>">delete</button>
            <br />
        <?php endforeach ?>
</body>
</html>
