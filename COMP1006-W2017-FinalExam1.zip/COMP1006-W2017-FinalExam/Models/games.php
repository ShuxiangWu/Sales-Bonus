<?php

 class Game {

    function __construct($name, $cost) {
        $this->name = $name;
        $this->cost = $cost;
    }
}


?>