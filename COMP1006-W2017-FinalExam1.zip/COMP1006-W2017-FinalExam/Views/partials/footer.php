
<!-- JavaScript Section -->
<script src="Scripts/lib/jquery/dist/jquery.min.js"></script>
<script src="Scripts/lib/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="Scripts/app.js"></script>
</body>
</html>