<nav class="navbar navbar-default navbar-fixed-bottom">
    <div class="container">
        <h4>&copy; Copyright 2017. All Rights reserved. </h4>
    </div>
</nav>