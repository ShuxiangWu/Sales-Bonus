<div class="container">
    <div class="row">
        <div class="col-md-offset-3 col-md-6">
            <h1>Oop! Page Not Found :(</h1>



        </div>
    </div>
</div>