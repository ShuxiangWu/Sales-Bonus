<div class="container">
    <div class="row">
        <div class="col-md-offset-3 col-md-6">
            <h1>About Us</h1>



        </div>
    </div>
</div>