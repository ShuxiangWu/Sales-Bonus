<div class="container">
            <div class="jumbotron">
                <h1>Welcome!</h1>
                <p>Some funky text goes here to welcome the user...</p>
            </div>
</div>